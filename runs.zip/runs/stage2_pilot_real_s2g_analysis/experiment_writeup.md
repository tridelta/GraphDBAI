# Experiment Writeup Draft

This file is generated from current experiment logs and is intended to be merged into `paper/paper_draft.md` after validation.

## Experimental Setup

Analyzed runs: 11.

## Implemented Baselines

Current code supports ReAct, Reflexion, VectorTrajectory, SkillLibrary, and ExperienceGraph. Interpret results according to completed run scale.

## Main Results

| agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | tokens_per_episode |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 14550.8000 |
| graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 5.6000 | 9306.2000 |
| react | full | medium | 2501 | 5 | 1.0000 | 6.6000 | 8908.8000 |
| reflexion | full | medium | 2501 | 5 | 0.6000 | 5 | 8731.6000 |
| skill_library | full | medium | 2501 | 5 | 0.6000 | 5.6667 | 7102.0000 |
| vector_trajectory | full | medium | 2501 | 5 | 0.4000 | 2.5000 | 7558.8000 |
| graph | full | medium | 2501 | 5 | 0.4000 | 2.5000 | 19834.4000 |
| graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 6.4000 | 10169.6000 |
| reflexion | full | medium | 2501 | 5 | 0.8000 | 5.5000 | 13836.4000 |
| skill_library | full | medium | 2501 | 5 | 0.8000 | 6.2500 | 9647.2000 |
| vector_trajectory | full | medium | 2501 | 5 | 0.8000 | 5.5000 | 12593.2000 |

## Limitations and Deviations from Original Draft

- Pilot-scale runs should not replace projected paper claims until the planned seed and episode counts are complete.
- If semantic node merging is not enabled, node-merge quality claims must be restricted to deterministic rule-based merging.
- If TextCraft uses fixed case schedules rather than procedural initial-state sampling, describe seed as controlling case order rather than environment distribution.
