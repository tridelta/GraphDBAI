# Experiment Summary

Runs analyzed: 11

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_s2g_graph_full_medium_seed2501 | graph | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 72754 |
| stage2_pilot_real_s2g_graph_no_graph_context_medium_seed2501 | graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 5.6000 | 46531 |
| stage2_pilot_real_s2g_react_medium_seed2501 | react | full | medium | 2501 | 5 | 1.0000 | 6.6000 | 44544 |
| stage2_pilot_real_s2g_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 0.6000 | 5 | 43658 |
| stage2_pilot_real_s2g_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.6000 | 5.6667 | 35510 |
| stage2_pilot_real_s2g_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 0.4000 | 2.5000 | 37794 |
| stage2_pilot_real_s2g_warm_graph_full_medium_seed2501 | graph | full | medium | 2501 | 5 | 0.4000 | 2.5000 | 99172 |
| stage2_pilot_real_s2g_warm_graph_no_graph_context_medium_seed2501 | graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 6.4000 | 50848 |
| stage2_pilot_real_s2g_warm_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 0.8000 | 5.5000 | 69182 |
| stage2_pilot_real_s2g_warm_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.8000 | 6.2500 | 48236 |
| stage2_pilot_real_s2g_warm_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 0.8000 | 5.5000 | 62966 |
