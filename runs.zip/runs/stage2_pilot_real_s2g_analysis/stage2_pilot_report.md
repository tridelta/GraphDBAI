# Stage 2 Pilot Report

This report is generated from real external-LLM run logs. Treat all numbers as pilot observations, not final paper claims.

## Setup

- Provider/model: deepseek / `deepseek-v4-flash`.
- Difficulty: `medium`; seed: `2501`; case schedule: `shuffled_cycle`.
- Episodes requested/completed per run: 5 / 5; max steps: 12.
- Estimated total cost: 0.9884 RMB using the configured token-price estimate.
- Figures are generated with `matplotlib.pyplot` from the analyzed JSONL/CSV artifacts.

## Audit Context

- Earlier `stage2_pilot_real_s2c_*` runs should be treated as affected by prompt leakage and stale ambiguous-state logging.
- This report uses the analyzed run prefix passed to `tools/analyze_stage2.py`; keep these pilot results separate from `[PROJECTED]` paper claims.

## Main Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 5 | 0.600 | 4.333 | 14550.8 | 0.1255 | 13/19/5 |
| graph | full | 5 | 0.400 | 2.500 | 19834.4 | 0.1460 | 13/20/8 |
| graph | no_graph_context | 5 | 1.000 | 5.600 | 9306.2 | 0.0827 | 14/16/5 |
| graph | no_graph_context | 5 | 1.000 | 6.400 | 10169.6 | 0.0875 | 14/16/6 |
| react | full | 5 | 1.000 | 6.600 | 8908.8 | 0.0703 | 14/19/5 |
| reflexion | full | 5 | 0.600 | 5.000 | 8731.6 | 0.0822 | 10/17/5 |
| reflexion | full | 5 | 0.800 | 5.500 | 13836.4 | 0.1096 | 14/21/8 |
| skill_library | full | 5 | 0.600 | 5.667 | 7102.0 | 0.0606 | 10/12/5 |
| skill_library | full | 5 | 0.800 | 6.250 | 9647.2 | 0.0701 | 15/20/7 |
| vector_trajectory | full | 5 | 0.400 | 2.500 | 7558.8 | 0.0607 | 9/13/5 |
| vector_trajectory | full | 5 | 0.800 | 5.500 | 12593.2 | 0.0932 | 13/21/8 |

## Prompt and Retrieval Diagnostics

| agent | hidden_fact_prompts | avg_candidate_paths | avg_cross_task_paths | avg_retrieved_skills | avg_retrieved_trajectories | repeated_action_alerts | llm_retries | finish_reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| graph | 0 | 1.571 | 0.000 | 0.000 | 0.000 | 6 | 0 | stop: 28 |
| graph | 0 | 5.000 | 0.000 | 0.000 | 0.000 | 9 | 0 | stop: 24 |
| graph | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0 | stop: 28 |
| graph | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 8 | 0 | stop: 32 |
| react | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0 | stop: 33 |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 4 | 0 | stop: 23 |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 11 | 1 | stop: 34 |
| skill_library | 0 | 0.000 | 0.000 | 1.045 | 0.000 | 8 | 0 | stop: 22 |
| skill_library | 0 | 0.000 | 0.000 | 4.133 | 0.000 | 9 | 0 | stop: 30 |
| vector_trajectory | 0 | 0.000 | 0.000 | 0.000 | 1.375 | 8 | 0 | stop: 24 |
| vector_trajectory | 0 | 0.000 | 0.000 | 0.000 | 5.000 | 11 | 0 | stop: 34 |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | village_search_unavailable: 1; incorrect_impossible_report: 1 | 0 |
| graph | none | 0 |
| graph | step_budget_exhausted: 1; incorrect_impossible_report: 2 | 0 |
| graph | none | 0 |
| react | none | 0 |
| reflexion | incorrect_impossible_report: 2 | 0 |
| reflexion | step_budget_exhausted: 1 | 0 |
| skill_library | incorrect_impossible_report: 1; premature_impossible_report: 1 | 0 |
| skill_library | incorrect_impossible_report: 1 | 0 |
| vector_trajectory | step_budget_exhausted: 1; incorrect_impossible_report: 2 | 0 |
| vector_trajectory | step_budget_exhausted: 1 | 0 |

## Observations

- ExperienceGraph completed 5 episodes with success_rate=0.600; final graph size was 13 nodes, 19 edges, 5 paths.
- Prompt hidden-fact detections in this analyzed set: 0.
- ReAct, Reflexion, SkillLibrary, and VectorTrajectory do not consume graph candidate paths unless they are explicitly wired to do so; any runner-built graph metrics should be interpreted separately from agent-consumed graph context.
- The current per-run episode count (5) is useful for prompt, logging, budget, and basic behavior checks, but it is not enough for performance claims.

## Log Inspection Pointers

| agent | episode | step | failure_reason | action_or_output |
| --- | --- | --- | --- | --- |
| graph | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| graph | ep_0000 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| react | ep_0000 | 2 | mine_search_unavailable | {"name": "explore", "args": {"target": "mine"}} |
| reflexion | ep_0000 | 2 | village_search_unavailable | {"name": "explore", "args": {"target": "village"}} |
| skill_library | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| skill_library | ep_0000 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| vector_trajectory | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| vector_trajectory | ep_0000 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |

## Artifacts

- Main table: `runs\stage2_pilot_real_s2g_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_pilot_real_s2g_analysis\token_cost.csv`
- Analysis summary JSON: `runs\stage2_pilot_real_s2g_analysis\analysis_summary.json`
- Graph growth table: `runs\stage2_pilot_real_s2g_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_pilot_real_s2g_analysis\figures\learning_curve_medium.png`
- Graph growth figure: `runs\stage2_pilot_real_s2g_analysis\figures\graph_growth.png`
- Token cost figure: `runs\stage2_pilot_real_s2g_analysis\figures\token_cost.png`
- Episode viewer: `tools/episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Claim-Evidence Map

| Claim | Evidence | Status |
| --- | --- | --- |
| Fixed Stage 2 logs no longer expose hidden facts in prompts | `hidden_fact_prompts` table above | Supported for this pilot if the count is 0 |
| Agents can complete the medium TextCraft flow with real external LLM calls | `success_rate` and failure table above | Pilot observation |
| ExperienceGraph graph context is available to the graph agent | `avg_candidate_paths` plus graph growth artifacts | Pilot observation |
| Pilot numbers replace paper-scale `[PROJECTED]` claims | Only 5 episodes per method | Not supported |

## Limitations and Deviations from Original Draft

- This is a Stage 2 pilot, not a 300-episode multi-seed full run.
- Baseline and ablation results should remain separate from paper main tables until the planned scale is complete.
- If semantic node merging is not enabled, node-merge quality claims must stay limited to deterministic rule-based merging.
