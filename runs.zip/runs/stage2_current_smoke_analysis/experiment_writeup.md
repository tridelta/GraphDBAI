# Experiment Writeup Draft

This file is generated from current experiment logs and is intended to be merged into `paper/paper_draft.md` after validation.

## Experimental Setup

Analyzed runs: 34.

## Implemented Baselines

Current code supports ReAct, Reflexion, VectorTrajectory, SkillLibrary, and ExperienceGraph. Interpret results according to completed run scale.

## Main Results

| agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | tokens_per_episode |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | all | 202 | 1 | 0.0000 |  | 487.0000 |
| scripted | full | all | 101 | 2 | 1.0000 | 4.5000 | 0.0000 |
| graph | no_graph_context | medium | 11 | 1 | 0.0000 |  | 453.0000 |
| scripted | full | easy | 7 | 2 | 0.5000 | 4 | 0.0000 |
| scripted | no_node_merging | easy | 17 | 1 | 1.0000 | 4 | 0.0000 |
| scripted | full | easy | 13 | 1 | 1.0000 | 4 | 0.0000 |
| scripted | None | None | None | 12 | 0.6667 | 6 | 0.0000 |
| scripted | None | None | None | 12 | 0.6667 | 6 | 0.0000 |
| graph | full | easy | 1201 | 2 | 0.0000 |  | 577.0000 |
| graph | full | medium | 1201 | 2 | 0.0000 |  | 7452.5000 |
| graph | no_failure_preconditions | medium | 1201 | 2 | 0.0000 |  | 7452.5000 |
| graph | no_graph_context | medium | 1201 | 2 | 0.0000 |  | 6057.0000 |
| graph | no_node_merging | medium | 1201 | 2 | 0.0000 |  | 7452.5000 |
| graph | no_statistics | medium | 1201 | 2 | 0.0000 |  | 7440.5000 |
| graph | random_retrieval | medium | 1201 | 2 | 0.0000 |  | 7452.5000 |
| react | full | easy | 1201 | 2 | 0.0000 |  | 427.0000 |
| react | full | medium | 1201 | 2 | 0.0000 |  | 5325.0000 |
| reflexion | full | easy | 1201 | 2 | 0.0000 |  | 464.0000 |
| reflexion | full | medium | 1201 | 2 | 0.0000 |  | 6096.5000 |
| scripted | full | easy | 1201 | 2 | 0.5000 | 5 | 0.0000 |
| scripted | no_failure_preconditions | medium | 1201 | 2 | 1.0000 | 2.5000 | 0.0000 |
| scripted | no_node_merging | medium | 1201 | 2 | 1.0000 | 2.5000 | 0.0000 |
| skill_library | full | easy | 1201 | 2 | 0.0000 |  | 448.0000 |
| skill_library | full | medium | 1201 | 2 | 0.0000 |  | 5577.0000 |
| vector_trajectory | full | easy | 1201 | 2 | 0.0000 |  | 475.5000 |
| vector_trajectory | full | medium | 1201 | 2 | 0.0000 |  | 6235.0000 |
| graph | full | easy | 25 | 2 | 0.0000 |  | 555.0000 |
| graph | full | easy | 32 | 2 | 0.0000 |  | 579.0000 |
| reflexion | no_graph_context | easy | 22 | 1 | 0.0000 |  | 438.0000 |
| scripted | full | easy | 41 | 2 | 1.0000 | 4.5000 | 0.0000 |
| scripted | full | easy | 21 | 1 | 0.0000 |  | 0.0000 |
| scripted | full | easy | 31 | 1 | 1.0000 | 4 | 0.0000 |
| skill_library | no_graph_context | easy | 24 | 1 | 0.0000 |  | 448.0000 |
| vector_trajectory | no_graph_context | easy | 23 | 1 | 0.0000 |  | 447.0000 |

## Limitations and Deviations from Original Draft

- Pilot-scale runs should not replace projected paper claims until the planned seed and episode counts are complete.
- If semantic node merging is not enabled, node-merge quality claims must be restricted to deterministic rule-based merging.
- If TextCraft uses fixed case schedules rather than procedural initial-state sampling, describe seed as controlling case order rather than environment distribution.
