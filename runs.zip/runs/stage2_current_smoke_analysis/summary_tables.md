# Experiment Summary

Runs analyzed: 34

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| final_check_graph_fake_20260620_1536 | graph | full | all | 202 | 1 | 0.0000 |  | 487 |
| final_check_scripted_20260620_1535 | scripted | full | all | 101 | 2 | 1.0000 | 4.5000 | 0 |
| smoke_fake_graph_logging | graph | no_graph_context | medium | 11 | 1 | 0.0000 |  | 453 |
| smoke_framework_check | scripted | full | easy | 7 | 2 | 0.5000 | 4 | 0 |
| smoke_no_node_merging | scripted | no_node_merging | easy | 17 | 1 | 1.0000 | 4 | 0 |
| smoke_scripted_provider_none | scripted | full | easy | 13 | 1 | 1.0000 | 4 | 0 |
| smoke_test | scripted | None | None | None | 12 | 0.6667 | 6 | 0 |
| smoke_test_2 | scripted | None | None | None | 12 | 0.6667 | 6 | 0 |
| stage2_current_graph_fake_easy | graph | full | easy | 1201 | 2 | 0.0000 |  | 1154 |
| stage2_current_graph_fake_medium_full | graph | full | medium | 1201 | 2 | 0.0000 |  | 14905 |
| stage2_current_graph_fake_medium_no_failure_preconditions | graph | no_failure_preconditions | medium | 1201 | 2 | 0.0000 |  | 14905 |
| stage2_current_graph_fake_medium_no_graph_context | graph | no_graph_context | medium | 1201 | 2 | 0.0000 |  | 12114 |
| stage2_current_graph_fake_medium_no_node_merging | graph | no_node_merging | medium | 1201 | 2 | 0.0000 |  | 14905 |
| stage2_current_graph_fake_medium_no_statistics | graph | no_statistics | medium | 1201 | 2 | 0.0000 |  | 14881 |
| stage2_current_graph_fake_medium_random_retrieval | graph | random_retrieval | medium | 1201 | 2 | 0.0000 |  | 14905 |
| stage2_current_react_fake_easy | react | full | easy | 1201 | 2 | 0.0000 |  | 854 |
| stage2_current_react_fake_medium | react | full | medium | 1201 | 2 | 0.0000 |  | 10650 |
| stage2_current_reflexion_fake_easy | reflexion | full | easy | 1201 | 2 | 0.0000 |  | 928 |
| stage2_current_reflexion_fake_medium | reflexion | full | medium | 1201 | 2 | 0.0000 |  | 12193 |
| stage2_current_scripted_easy | scripted | full | easy | 1201 | 2 | 0.5000 | 5 | 0 |
| stage2_current_scripted_medium_no_failure_preconditions | scripted | no_failure_preconditions | medium | 1201 | 2 | 1.0000 | 2.5000 | 0 |
| stage2_current_scripted_medium_no_node_merging | scripted | no_node_merging | medium | 1201 | 2 | 1.0000 | 2.5000 | 0 |
| stage2_current_skill_fake_easy | skill_library | full | easy | 1201 | 2 | 0.0000 |  | 896 |
| stage2_current_skill_fake_medium | skill_library | full | medium | 1201 | 2 | 0.0000 |  | 11154 |
| stage2_current_vector_fake_easy | vector_trajectory | full | easy | 1201 | 2 | 0.0000 |  | 951 |
| stage2_current_vector_fake_medium | vector_trajectory | full | medium | 1201 | 2 | 0.0000 |  | 12470 |
| stage2_graph_fake | graph | full | easy | 25 | 2 | 0.0000 |  | 1110 |
| stage2_graph_fake_preconditions | graph | full | easy | 32 | 2 | 0.0000 |  | 1158 |
| stage2_reflexion_fake | reflexion | no_graph_context | easy | 22 | 1 | 0.0000 |  | 438 |
| stage2_resume_check | scripted | full | easy | 41 | 2 | 1.0000 | 4.5000 | 0 |
| stage2_scripted_smoke | scripted | full | easy | 21 | 1 | 0.0000 |  | 0 |
| stage2_scripted_success_preconditions | scripted | full | easy | 31 | 1 | 1.0000 | 4 | 0 |
| stage2_skill_fake | skill_library | no_graph_context | easy | 24 | 1 | 0.0000 |  | 448 |
| stage2_vector_fake | vector_trajectory | no_graph_context | easy | 23 | 1 | 0.0000 |  | 447 |
