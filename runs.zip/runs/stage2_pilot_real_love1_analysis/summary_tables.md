# Experiment Summary

Runs analyzed: 6

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_love1_graph_full_medium_seed2501 | graph | full | medium | 2501 | 5 | 0.6000 | 4.6667 | 79623 |
| stage2_pilot_real_love1_graph_no_graph_context_medium_seed2501 | graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 5.6000 | 47990 |
| stage2_pilot_real_love1_react_medium_seed2501 | react | full | medium | 2501 | 5 | 1.0000 | 5.4000 | 34513 |
| stage2_pilot_real_love1_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 1.0000 | 6.8000 | 60793 |
| stage2_pilot_real_love1_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.6000 | 5.6667 | 31540 |
| stage2_pilot_real_love1_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 45368 |
