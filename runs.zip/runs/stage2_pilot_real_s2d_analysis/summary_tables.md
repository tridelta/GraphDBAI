# Experiment Summary

Runs analyzed: 5

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_s2d_graph_medium_seed2501 | graph | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 45225 |
| stage2_pilot_real_s2d_react_medium_seed2501 | react | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 24075 |
| stage2_pilot_real_s2d_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 0.4000 | 2.5000 | 24883 |
| stage2_pilot_real_s2d_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.2000 | 3 | 29249 |
| stage2_pilot_real_s2d_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 0.8000 | 5.5000 | 48595 |
