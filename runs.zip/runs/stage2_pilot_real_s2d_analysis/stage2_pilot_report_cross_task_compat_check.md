# Stage 2 Pilot Report

This report is generated from real external-LLM run logs. Treat all numbers as pilot observations, not final paper claims.

## Setup

- Provider/model: deepseek / `deepseek-v4-flash`.
- Difficulty: `medium`; seed: `2501`; case schedule: `shuffled_cycle`.
- Episodes requested/completed per run: 5 / 5; max steps: 12.
- Estimated total cost: 0.2834 RMB using the configured token-price estimate.
- Figures are generated with `matplotlib.pyplot` from the analyzed JSONL/CSV artifacts.

## Audit Context

- Earlier `stage2_pilot_real_s2c_*` runs should be treated as affected by prompt leakage and stale ambiguous-state logging.
- This report uses the analyzed run prefix passed to `tools/analyze_stage2.py`; keep these pilot results separate from `[PROJECTED]` paper claims.

## Main Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 5 | 0.600 | 4.333 | 9045.0 | 0.0717 | 13/17/5 |
| react | full | 5 | 0.600 | 4.333 | 4815.0 | 0.0414 | 13/15/5 |
| reflexion | full | 5 | 0.400 | 2.500 | 4976.6 | 0.0439 | 9/12/5 |
| skill_library | full | 5 | 0.200 | 3.000 | 5849.8 | 0.0524 | 9/13/5 |
| vector_trajectory | full | 5 | 0.800 | 5.500 | 9719.0 | 0.0740 | 13/17/5 |

## Prompt and Retrieval Diagnostics

| agent | hidden_fact_prompts | avg_candidate_paths | avg_cross_task_paths | avg_retrieved_skills | avg_retrieved_trajectories | repeated_action_alerts | llm_retries | finish_reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| graph | 0 | 2.000 | 0.000 | 0.000 | 0.000 | 1 | 0 |  |
| react | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 1 | 0 |  |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 0 | 0 |  |
| skill_library | 0 | 0.000 | 0.000 | 0.400 | 0.000 | 4 | 0 |  |
| vector_trajectory | 0 | 0.000 | 0.000 | 0.000 | 2.000 | 9 | 0 |  |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | village_search_unavailable: 1; invalid_llm_output: 1 | 1 |
| react | village_search_unavailable: 1; invalid_llm_output: 1 | 1 |
| reflexion | village_search_unavailable: 1; invalid_llm_output: 2 | 2 |
| skill_library | village_search_unavailable: 1; not_at_village: 1; invalid_llm_output: 2 | 2 |
| vector_trajectory | step_budget_exhausted: 1 | 0 |

## Observations

- ExperienceGraph completed 5 episodes with success_rate=0.600; final graph size was 13 nodes, 17 edges, 5 paths.
- Prompt hidden-fact detections in this analyzed set: 0.
- ReAct, Reflexion, SkillLibrary, and VectorTrajectory do not consume graph candidate paths unless they are explicitly wired to do so; any runner-built graph metrics should be interpreted separately from agent-consumed graph context.
- The current per-run episode count (5) is useful for prompt, logging, budget, and basic behavior checks, but it is not enough for performance claims.

## Log Inspection Pointers

| agent | episode | step | failure_reason | action_or_output |
| --- | --- | --- | --- | --- |
| graph | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| react | ep_0000 | 2 | village_search_unavailable | {"name": "explore", "args": {"target": "village"}} |
| reflexion | ep_0000 | 3 | village_search_unavailable | {"name": "explore", "args": {"target": "village"}} |
| skill_library | ep_0003 | 0 | None | {"name": "move_to", "args": {"location": "mine"}} |
| vector_trajectory | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |

## Artifacts

- Main table: `runs\stage2_pilot_real_s2d_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_pilot_real_s2d_analysis\token_cost.csv`
- Graph growth table: `runs\stage2_pilot_real_s2d_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_pilot_real_s2d_analysis\figures\learning_curve_medium.png`
- Graph growth figure: `runs\stage2_pilot_real_s2d_analysis\figures\graph_growth.png`
- Token cost figure: `runs\stage2_pilot_real_s2d_analysis\figures\token_cost.png`
- Episode viewer: `tools\episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Claim-Evidence Map

| Claim | Evidence | Status |
| --- | --- | --- |
| Fixed Stage 2 logs no longer expose hidden facts in prompts | `hidden_fact_prompts` table above | Supported for this pilot if the count is 0 |
| Agents can complete the medium TextCraft flow with real external LLM calls | `success_rate` and failure table above | Pilot observation |
| ExperienceGraph graph context is available to the graph agent | `avg_candidate_paths` plus graph growth artifacts | Pilot observation |
| Pilot numbers replace paper-scale `[PROJECTED]` claims | Only 5 episodes per method | Not supported |

## Limitations and Deviations from Original Draft

- This is a Stage 2 pilot, not a 300-episode multi-seed full run.
- Baseline and ablation results should remain separate from paper main tables until the planned scale is complete.
- If semantic node merging is not enabled, node-merge quality claims must stay limited to deterministic rule-based merging.
