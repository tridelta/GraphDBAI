# Experiment Writeup Draft

This file is generated from current experiment logs and is intended to be merged into `paper/paper_draft.md` after validation.

## Experimental Setup

Analyzed runs: 6.

## Implemented Baselines

Current code supports ReAct, Reflexion, VectorTrajectory, SkillLibrary, and ExperienceGraph. Interpret results according to completed run scale.

## Main Results

| agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | tokens_per_episode |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | medium | 2501 | 5 | 1.0000 | 6.8000 | 18212.2000 |
| graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 6.8000 | 12770.8000 |
| react | full | medium | 2501 | 5 | 0.8000 | 4.5000 | 6539.4000 |
| reflexion | full | medium | 2501 | 5 | 0.6000 | 3 | 4726.4000 |
| skill_library | full | medium | 2501 | 5 | 0.6000 | 4.6667 | 7048.2000 |
| vector_trajectory | full | medium | 2501 | 5 | 0.8000 | 5.7500 | 10690.2000 |

## Limitations and Deviations from Original Draft

- Pilot-scale runs should not replace projected paper claims until the planned seed and episode counts are complete.
- If semantic node merging is not enabled, node-merge quality claims must be restricted to deterministic rule-based merging.
- If TextCraft uses fixed case schedules rather than procedural initial-state sampling, describe seed as controlling case order rather than environment distribution.
