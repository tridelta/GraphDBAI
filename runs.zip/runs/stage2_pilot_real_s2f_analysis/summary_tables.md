# Experiment Summary

Runs analyzed: 6

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_s2f_graph_full_medium_seed2501 | graph | full | medium | 2501 | 5 | 1.0000 | 6.8000 | 91061 |
| stage2_pilot_real_s2f_graph_no_graph_context_medium_seed2501 | graph | no_graph_context | medium | 2501 | 5 | 1.0000 | 6.8000 | 63854 |
| stage2_pilot_real_s2f_react_medium_seed2501 | react | full | medium | 2501 | 5 | 0.8000 | 4.5000 | 32697 |
| stage2_pilot_real_s2f_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 0.6000 | 3 | 23632 |
| stage2_pilot_real_s2f_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.6000 | 4.6667 | 35241 |
| stage2_pilot_real_s2f_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 0.8000 | 5.7500 | 53451 |
