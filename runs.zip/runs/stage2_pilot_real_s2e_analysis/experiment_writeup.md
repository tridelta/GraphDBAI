# Experiment Writeup Draft

This file is generated from current experiment logs and is intended to be merged into `paper/paper_draft.md` after validation.

## Experimental Setup

Analyzed runs: 6.

## Implemented Baselines

Current code supports ReAct, Reflexion, VectorTrajectory, SkillLibrary, and ExperienceGraph. Interpret results according to completed run scale.

## Main Results

| agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | tokens_per_episode |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | medium | 2501 | 6 | 0.8333 | 6.2000 | 7533.6667 |
| graph | no_graph_context | medium | 2501 | 7 | 0.5714 | 5.5000 | 9623.0000 |
| react | full | medium | 2501 | 5 | 1.0000 | 5.8000 | 7641.4000 |
| reflexion | full | medium | 2501 | 5 | 0.8000 | 4.7500 | 7793.6000 |
| skill_library | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 4313.6000 |
| vector_trajectory | full | medium | 2501 | 5 | 1.0000 | 7 | 11055.0000 |

## Limitations and Deviations from Original Draft

- Pilot-scale runs should not replace projected paper claims until the planned seed and episode counts are complete.
- If semantic node merging is not enabled, node-merge quality claims must be restricted to deterministic rule-based merging.
- If TextCraft uses fixed case schedules rather than procedural initial-state sampling, describe seed as controlling case order rather than environment distribution.
