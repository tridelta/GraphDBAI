# Stage 2 Pilot Report

This report is generated from real external-LLM run logs. Treat all numbers as pilot observations, not final paper claims.

## Setup

- Provider/model: deepseek / `deepseek-v4-flash`.
- Difficulty: `medium`; seed: `2501`; case schedule: `shuffled_cycle`.
- Episodes requested/completed per run: 5 / 5, 6, 7; max steps: 12.
- Estimated total cost: 0.4517 RMB using the configured token-price estimate.
- Figures are generated with `matplotlib.pyplot` from the analyzed JSONL/CSV artifacts.

## Audit Context

- Earlier `stage2_pilot_real_s2c_*` runs should be treated as affected by prompt leakage and stale ambiguous-state logging.
- This report uses the analyzed run prefix passed to `tools/analyze_stage2.py`; keep these pilot results separate from `[PROJECTED]` paper claims.

## Main Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 6 | 0.833 | 6.200 | 7533.7 | 0.0794 | 13/15/5 |
| graph | no_graph_context | 7 | 0.571 | 5.500 | 9623.0 | 0.1265 | 13/17/5 |
| react | full | 5 | 1.000 | 5.800 | 7641.4 | 0.0589 | 15/19/5 |
| reflexion | full | 5 | 0.800 | 4.750 | 7793.6 | 0.0684 | 14/18/5 |
| skill_library | full | 5 | 0.600 | 4.333 | 4313.6 | 0.0339 | 7/10/4 |
| vector_trajectory | full | 5 | 1.000 | 7.000 | 11055.0 | 0.0845 | 14/17/5 |

## Prompt and Retrieval Diagnostics

| agent | hidden_fact_prompts | avg_candidate_paths | avg_cross_task_paths | avg_retrieved_skills | avg_retrieved_trajectories | repeated_action_alerts | llm_retries | finish_reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| graph | 0 | 2.381 | 0.000 | 0.000 | 0.000 | 12 | 1 | stop: 42 |
| graph | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 7 | 3 | stop: 35 |
| react | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 2 | 0 | stop: 29 |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 0.000 | 1 | 0 | stop: 22 |
| skill_library | 0 | 0.000 | 0.000 | 0.933 | 0.000 | 2 | 0 | stop: 15 |
| vector_trajectory | 0 | 0.000 | 0.000 | 0.000 | 1.971 | 10 | 0 | stop: 35 |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | step_budget_exhausted: 1 | 0 |
| graph | village_search_unavailable: 1; incorrect_impossible_report: 2 | 0 |
| react | none | 0 |
| reflexion | incorrect_impossible_report: 1 | 0 |
| skill_library | incorrect_impossible_report: 1; premature_impossible_report: 1 | 0 |
| vector_trajectory | none | 0 |

## Observations

- ExperienceGraph completed 6 episodes with success_rate=0.833; final graph size was 13 nodes, 15 edges, 5 paths.
- Prompt hidden-fact detections in this analyzed set: 0.
- ReAct, Reflexion, SkillLibrary, and VectorTrajectory do not consume graph candidate paths unless they are explicitly wired to do so; any runner-built graph metrics should be interpreted separately from agent-consumed graph context.
- The current per-run episode count (5, 6, 7) is useful for prompt, logging, budget, and basic behavior checks, but it is not enough for performance claims.

## Log Inspection Pointers

| agent | episode | step | failure_reason | action_or_output |
| --- | --- | --- | --- | --- |
| graph | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| graph | ep_0000 | 7 | village_search_unavailable | {"name": "explore", "args": {"target": "village"}} |
| react | ep_0000 | 2 | village_search_unavailable | {"name": "explore", "args": {"target": "village"}} |
| reflexion | ep_0001 | 0 | not_at_village | {"name": "trade", "args": {"villager": "armorer", "offer": "emerald", "want": "diamond_set"}} |
| skill_library | ep_0001 | 0 | None | {"name": "move_to", "args": {"location": "village"}} |
| vector_trajectory | ep_0001 | 0 | not_at_village | {"name": "trade", "args": {"villager": "armorer", "offer": "emerald", "want": "diamond_set"}} |

## Artifacts

- Main table: `runs\stage2_pilot_real_s2e_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_pilot_real_s2e_analysis\token_cost.csv`
- Graph growth table: `runs\stage2_pilot_real_s2e_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_pilot_real_s2e_analysis\figures\learning_curve_medium.png`
- Graph growth figure: `runs\stage2_pilot_real_s2e_analysis\figures\graph_growth.png`
- Token cost figure: `runs\stage2_pilot_real_s2e_analysis\figures\token_cost.png`
- Episode viewer: `tools/episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Claim-Evidence Map

| Claim | Evidence | Status |
| --- | --- | --- |
| Fixed Stage 2 logs no longer expose hidden facts in prompts | `hidden_fact_prompts` table above | Supported for this pilot if the count is 0 |
| Agents can complete the medium TextCraft flow with real external LLM calls | `success_rate` and failure table above | Pilot observation |
| ExperienceGraph graph context is available to the graph agent | `avg_candidate_paths` plus graph growth artifacts | Pilot observation |
| Pilot numbers replace paper-scale `[PROJECTED]` claims | Only 5 episodes per method | Not supported |

## Limitations and Deviations from Original Draft

- This is a Stage 2 pilot, not a 300-episode multi-seed full run.
- Baseline and ablation results should remain separate from paper main tables until the planned scale is complete.
- If semantic node merging is not enabled, node-merge quality claims must stay limited to deterministic rule-based merging.
