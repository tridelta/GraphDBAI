# Experiment Summary

Runs analyzed: 6

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_s2e_graph_full_medium_seed2501 | graph | full | medium | 2501 | 6 | 0.8333 | 6.2000 | 45202 |
| stage2_pilot_real_s2e_graph_no_graph_context_medium_seed2501 | graph | no_graph_context | medium | 2501 | 7 | 0.5714 | 5.5000 | 67361 |
| stage2_pilot_real_s2e_react_medium_seed2501 | react | full | medium | 2501 | 5 | 1.0000 | 5.8000 | 38207 |
| stage2_pilot_real_s2e_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 5 | 0.8000 | 4.7500 | 38968 |
| stage2_pilot_real_s2e_skill_library_medium_seed2501 | skill_library | full | medium | 2501 | 5 | 0.6000 | 4.3333 | 21568 |
| stage2_pilot_real_s2e_vector_trajectory_medium_seed2501 | vector_trajectory | full | medium | 2501 | 5 | 1.0000 | 7 | 55275 |
