# Stage 2 Pilot Report

This report is generated from local smoke/preflight run logs. Treat all numbers as pilot observations, not final paper claims.

## Setup

- Provider/model: fake / `fake`.
- Difficulty: `medium`; seed: `2501`; case schedule: `shuffled_cycle`.
- Episodes requested/completed per run: 1 / 1; max steps: 3.
- Estimated total cost: 0.0117 RMB using the configured token-price estimate.
- Figures are generated with `matplotlib.pyplot` from the analyzed JSONL/CSV artifacts.

## Audit Context

- Earlier `stage2_pilot_real_s2c_*` runs should be treated as affected by prompt leakage and stale ambiguous-state logging.
- This report uses the analyzed run prefix passed to `tools/analyze_stage2.py`; keep these pilot results separate from `[PROJECTED]` paper claims.

## Main Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 1 | 0.000 |  | 2346.0 | 0.0025 | 2/2/1 |
| react | full | 1 | 0.000 |  | 2136.0 | 0.0023 | 2/2/1 |
| reflexion | full | 1 | 0.000 |  | 2172.0 | 0.0023 | 2/2/1 |
| skill_library | full | 1 | 0.000 |  | 2184.0 | 0.0023 | 2/2/1 |
| vector_trajectory | full | 1 | 0.000 |  | 2199.0 | 0.0023 | 2/2/1 |

## Prompt and Retrieval Diagnostics

| agent | hidden_fact_prompts | avg_candidate_paths | avg_retrieved_skills | avg_retrieved_trajectories | repeated_action_alerts |
| --- | --- | --- | --- | --- | --- |
| graph | 0 | 0.000 | 0.000 | 0.000 | 1 |
| react | 0 | 0.000 | 0.000 | 0.000 | 1 |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 1 |
| skill_library | 0 | 0.000 | 0.000 | 0.000 | 1 |
| vector_trajectory | 0 | 0.000 | 0.000 | 0.000 | 1 |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | step_budget_exhausted: 1 | 0 |
| react | step_budget_exhausted: 1 | 0 |
| reflexion | step_budget_exhausted: 1 | 0 |
| skill_library | step_budget_exhausted: 1 | 0 |
| vector_trajectory | step_budget_exhausted: 1 | 0 |

## Observations

- ExperienceGraph completed 1 episodes with success_rate=0.000; final graph size was 2 nodes, 2 edges, 1 paths.
- Prompt hidden-fact detections in this analyzed set: 0.
- ReAct, Reflexion, SkillLibrary, and VectorTrajectory do not consume graph candidate paths unless they are explicitly wired to do so; any runner-built graph metrics should be interpreted separately from agent-consumed graph context.
- The current per-run episode count (1) is useful for prompt, logging, budget, and basic behavior checks, but it is not enough for performance claims.

## Artifacts

- Main table: `runs\stage2_5ep_smoke_20260620_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_5ep_smoke_20260620_analysis\token_cost.csv`
- Graph growth table: `runs\stage2_5ep_smoke_20260620_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_5ep_smoke_20260620_analysis\figures\learning_curve_medium.png`
- Graph growth figure: `runs\stage2_5ep_smoke_20260620_analysis\figures\graph_growth.png`
- Token cost figure: `runs\stage2_5ep_smoke_20260620_analysis\figures\token_cost.png`
- Episode viewer: `tools\episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Claim-Evidence Map

| Claim | Evidence | Status |
| --- | --- | --- |
| Fixed Stage 2 logs no longer expose hidden facts in prompts | `hidden_fact_prompts` table above | Supported for this pilot if the count is 0 |
| Agents can complete the medium TextCraft flow with real external LLM calls | `success_rate` and failure table above | Not evaluated in local preflight |
| ExperienceGraph graph context is available to the graph agent | `avg_candidate_paths` plus graph growth artifacts | Pilot observation |
| Pilot numbers replace paper-scale `[PROJECTED]` claims | Only 5 episodes per method | Not supported |

## Limitations and Deviations from Original Draft

- This is a Stage 2 pilot, not a 300-episode multi-seed full run.
- Baseline and ablation results should remain separate from paper main tables until the planned scale is complete.
- If semantic node merging is not enabled, node-merge quality claims must stay limited to deterministic rule-based merging.
