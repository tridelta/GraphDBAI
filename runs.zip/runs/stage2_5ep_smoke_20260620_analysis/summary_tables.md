# Experiment Summary

Runs analyzed: 5

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_5ep_smoke_20260620_graph_fake_medium | graph | full | medium | 2501 | 1 | 0.0000 |  | 2346 |
| stage2_5ep_smoke_20260620_react_fake_medium | react | full | medium | 2501 | 1 | 0.0000 |  | 2136 |
| stage2_5ep_smoke_20260620_reflexion_fake_medium | reflexion | full | medium | 2501 | 1 | 0.0000 |  | 2172 |
| stage2_5ep_smoke_20260620_skill_fake_medium | skill_library | full | medium | 2501 | 1 | 0.0000 |  | 2184 |
| stage2_5ep_smoke_20260620_vector_fake_medium | vector_trajectory | full | medium | 2501 | 1 | 0.0000 |  | 2199 |
