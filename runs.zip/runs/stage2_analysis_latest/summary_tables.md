# Experiment Summary

Runs analyzed: 14

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| smoke_fake_graph_logging | graph | no_graph_context | medium | 11 | 1 | 0.0000 |  | 453 |
| smoke_framework_check | scripted | full | easy | 7 | 2 | 0.5000 | 4 | 0 |
| smoke_no_node_merging | scripted | no_node_merging | easy | 17 | 1 | 1.0000 | 4 | 0 |
| smoke_scripted_provider_none | scripted | full | easy | 13 | 1 | 1.0000 | 4 | 0 |
| smoke_test | scripted | None | None | None | 12 | 0.6667 | 6 | 0 |
| smoke_test_2 | scripted | None | None | None | 12 | 0.6667 | 6 | 0 |
| stage2_graph_fake | graph | full | easy | 25 | 2 | 0.0000 |  | 1110 |
| stage2_graph_fake_preconditions | graph | full | easy | 32 | 2 | 0.0000 |  | 1158 |
| stage2_reflexion_fake | reflexion | no_graph_context | easy | 22 | 1 | 0.0000 |  | 438 |
| stage2_resume_check | scripted | full | easy | 41 | 2 | 1.0000 | 4.5000 | 0 |
| stage2_scripted_smoke | scripted | full | easy | 21 | 1 | 0.0000 |  | 0 |
| stage2_scripted_success_preconditions | scripted | full | easy | 31 | 1 | 1.0000 | 4 | 0 |
| stage2_skill_fake | skill_library | no_graph_context | easy | 24 | 1 | 0.0000 |  | 448 |
| stage2_vector_fake | vector_trajectory | no_graph_context | easy | 23 | 1 | 0.0000 |  | 447 |
