# Stage 2 Pilot Report

This report is generated from local smoke/preflight run logs. Treat all numbers as pilot observations, not final paper claims.

## Setup

- Provider/model: fake / `fake`.
- Difficulty: `medium`; seed: `2501`; case schedule: `shuffled_cycle`.
- Episodes requested/completed per run: 5 / 5; max steps: 12.
- Estimated total cost: 0.1660 RMB using the configured token-price estimate.
- Figures are generated with `matplotlib.pyplot` from the analyzed JSONL/CSV artifacts.

## Audit Context

- Earlier `stage2_pilot_real_s2c_*` runs should be treated as affected by prompt leakage and stale ambiguous-state logging.
- This report uses the analyzed run prefix passed to `tools/analyze_stage2.py`; keep these pilot results separate from `[PROJECTED]` paper claims.

## Main Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 5 | 0.000 |  | 7816.6 | 0.0407 | 4/5/3 |
| react | full | 5 | 0.000 |  | 5391.2 | 0.0286 | 4/5/3 |
| reflexion | full | 5 | 0.000 |  | 6388.8 | 0.0335 | 4/5/3 |
| skill_library | full | 5 | 0.000 |  | 5510.0 | 0.0291 | 4/5/3 |
| vector_trajectory | full | 5 | 0.000 |  | 6503.8 | 0.0341 | 4/5/3 |

## Prompt and Retrieval Diagnostics

| agent | hidden_fact_prompts | avg_candidate_paths | avg_retrieved_skills | avg_retrieved_trajectories | repeated_action_alerts |
| --- | --- | --- | --- | --- | --- |
| graph | 0 | 1.079 | 0.000 | 0.000 | 30 |
| react | 0 | 0.000 | 0.000 | 0.000 | 30 |
| reflexion | 0 | 0.000 | 0.000 | 0.000 | 30 |
| skill_library | 0 | 0.000 | 0.000 | 0.000 | 30 |
| vector_trajectory | 0 | 0.000 | 0.000 | 1.132 | 30 |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | step_budget_exhausted: 3; village_not_discovered: 2 | 0 |
| react | step_budget_exhausted: 3; village_not_discovered: 2 | 0 |
| reflexion | step_budget_exhausted: 3; village_not_discovered: 2 | 0 |
| skill_library | step_budget_exhausted: 3; village_not_discovered: 2 | 0 |
| vector_trajectory | step_budget_exhausted: 3; village_not_discovered: 2 | 0 |

## Observations

- ExperienceGraph completed 5 episodes with success_rate=0.000; final graph size was 4 nodes, 5 edges, 3 paths.
- Prompt hidden-fact detections in this analyzed set: 0.
- ReAct, Reflexion, SkillLibrary, and VectorTrajectory do not consume graph candidate paths unless they are explicitly wired to do so; any runner-built graph metrics should be interpreted separately from agent-consumed graph context.
- The current per-run episode count (5) is useful for prompt, logging, budget, and basic behavior checks, but it is not enough for performance claims.

## Log Inspection Pointers

| agent | episode | step | failure_reason | action_or_output |
| --- | --- | --- | --- | --- |
| graph | ep_0001 | 0 | None | {"name": "inspect", "args": {"target": "village"}} |
| react | ep_0003 | 0 | village_not_discovered | {"name": "inspect", "args": {"target": "village"}} |
| reflexion | ep_0003 | 0 | village_not_discovered | {"name": "inspect", "args": {"target": "village"}} |
| skill_library | ep_0003 | 0 | village_not_discovered | {"name": "inspect", "args": {"target": "village"}} |
| vector_trajectory | ep_0001 | 0 | None | {"name": "inspect", "args": {"target": "village"}} |

## Artifacts

- Main table: `runs\stage2_5ep_preflight_20260620_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_5ep_preflight_20260620_analysis\token_cost.csv`
- Graph growth table: `runs\stage2_5ep_preflight_20260620_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_5ep_preflight_20260620_analysis\figures\learning_curve_medium.png`
- Graph growth figure: `runs\stage2_5ep_preflight_20260620_analysis\figures\graph_growth.png`
- Token cost figure: `runs\stage2_5ep_preflight_20260620_analysis\figures\token_cost.png`
- Episode viewer: `tools\episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Claim-Evidence Map

| Claim | Evidence | Status |
| --- | --- | --- |
| Fixed Stage 2 logs no longer expose hidden facts in prompts | `hidden_fact_prompts` table above | Supported for this pilot if the count is 0 |
| Agents can complete the medium TextCraft flow with real external LLM calls | `success_rate` and failure table above | Not evaluated in local preflight |
| ExperienceGraph graph context is available to the graph agent | `avg_candidate_paths` plus graph growth artifacts | Pilot observation |
| Pilot numbers replace paper-scale `[PROJECTED]` claims | Only 5 episodes per method | Not supported |

## Limitations and Deviations from Original Draft

- This is a Stage 2 pilot, not a 300-episode multi-seed full run.
- Baseline and ablation results should remain separate from paper main tables until the planned scale is complete.
- If semantic node merging is not enabled, node-merge quality claims must stay limited to deterministic rule-based merging.
