# Experiment Summary

Runs analyzed: 5

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_5ep_preflight_20260620_graph_fake_medium | graph | full | medium | 2501 | 5 | 0.0000 |  | 39083 |
| stage2_5ep_preflight_20260620_react_fake_medium | react | full | medium | 2501 | 5 | 0.0000 |  | 26956 |
| stage2_5ep_preflight_20260620_reflexion_fake_medium | reflexion | full | medium | 2501 | 5 | 0.0000 |  | 31944 |
| stage2_5ep_preflight_20260620_skill_fake_medium | skill_library | full | medium | 2501 | 5 | 0.0000 |  | 27550 |
| stage2_5ep_preflight_20260620_vector_fake_medium | vector_trajectory | full | medium | 2501 | 5 | 0.0000 |  | 32519 |
