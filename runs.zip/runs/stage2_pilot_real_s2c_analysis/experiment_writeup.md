# Experiment Writeup Draft

This file is generated from current experiment logs and is intended to be merged into `paper/paper_draft.md` after validation.

## Experimental Setup

Analyzed runs: 5.

## Implemented Baselines

Current code supports ReAct, Reflexion, VectorTrajectory, SkillLibrary, and ExperienceGraph. Interpret results according to completed run scale.

## Main Results

| agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | tokens_per_episode |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 9196.6667 |
| react | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 6835.3333 |
| reflexion | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 2804.6667 |
| skill_library | full | medium | 2501 | 3 | 0.3333 | 3 | 6225.3333 |
| vector_trajectory | full | medium | 2501 | 3 | 0.3333 | 2 | 6240.3333 |

## Limitations and Deviations from Original Draft

- Pilot-scale runs should not replace projected paper claims until the planned seed and episode counts are complete.
- If semantic node merging is not enabled, node-merge quality claims must be restricted to deterministic rule-based merging.
- If TextCraft uses fixed case schedules rather than procedural initial-state sampling, describe seed as controlling case order rather than environment distribution.
