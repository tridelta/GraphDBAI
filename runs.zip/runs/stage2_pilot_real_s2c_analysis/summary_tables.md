# Experiment Summary

Runs analyzed: 5

## Run-Level Results
| run_id | agent | variant | difficulty | seed | episodes_completed | success_rate | avg_steps_success | total_tokens |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| stage2_pilot_real_s2c_graph_medium_seed2501 | graph | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 27590 |
| stage2_pilot_real_s2c_react_medium_seed2501 | react | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 20506 |
| stage2_pilot_real_s2c_reflexion_medium_seed2501 | reflexion | full | medium | 2501 | 3 | 0.6667 | 2.5000 | 8414 |
| stage2_pilot_real_s2c_skill_medium_seed2501 | skill_library | full | medium | 2501 | 3 | 0.3333 | 3 | 18676 |
| stage2_pilot_real_s2c_vector_medium_seed2501 | vector_trajectory | full | medium | 2501 | 3 | 0.3333 | 2 | 18721 |
