# Stage 2 Pilot Report

This report is generated from real DeepSeek runs. Treat all results as pilot observations, not final paper claims.

## Setup

- Provider/model: DeepSeek `deepseek-v4-flash`.
- Difficulty: `medium`.
- Seed: `2501`; all methods use the same shuffled case schedule.
- Episodes per method: 3; max steps per episode: 12.
- JSON mode: `response_format={"type": "json_object"}` plus an explicit JSON example in the prompt; DeepSeek max output tokens default to 2048.
- Estimated total cost: 0.1479 RMB using the configured token-price estimate.

## Results

| agent | variant | episodes | success_rate | avg_success_steps | tokens/episode | cost_rmb | nodes/edges/paths |
| --- | --- | --- | --- | --- | --- | --- | --- |
| graph | full | 3 | 0.667 | 2.500 | 9196.7 | 0.0459 | 6/6/3 |
| react | full | 3 | 0.667 | 2.500 | 6835.3 | 0.0317 | 6/6/3 |
| reflexion | full | 3 | 0.667 | 2.500 | 2804.7 | 0.0140 | 5/4/2 |
| skill_library | full | 3 | 0.333 | 3.000 | 6225.3 | 0.0277 | 6/6/3 |
| vector_trajectory | full | 3 | 0.333 | 2.000 | 6240.3 | 0.0286 | 6/5/2 |

## Failure Modes

| agent | episode failure reasons | json_parse_or_empty_outputs |
| --- | --- | --- |
| graph | step_budget_exhausted: 1 | 0 |
| react | step_budget_exhausted: 1 | 0 |
| reflexion | no_armorer_and_no_mine: 1 | 1 |
| skill_library | step_budget_exhausted: 1; not_at_village: 1 | 0 |
| vector_trajectory | no_armorer: 1; invalid_llm_output: 1 | 1 |

## Observations

- ExperienceGraph completed 3 episodes with success_rate=0.667; final graph size was 6 nodes, 6 edges, 3 paths.
- The shared TextCraft action guide materially improved valid action selection compared with the first connectivity run.
- Root-level action JSON such as `{"name":..., "args":...}` is now accepted as a valid action, reducing avoidable schema failures.
- Malformed or truncated model output is now logged as an invalid step instead of crashing the run.
- Pilot scale is too small for performance claims; it is useful mainly for prompt, logging, budget, and tool readiness checks.

## Artifacts

- Main table: `runs\stage2_pilot_real_s2c_analysis\main_comparison.csv`
- Token cost table: `runs\stage2_pilot_real_s2c_analysis\token_cost.csv`
- Graph growth table: `runs\stage2_pilot_real_s2c_analysis\graph_growth.csv`
- Learning curve: `runs\stage2_pilot_real_s2c_analysis\figures\learning_curve_medium.svg`
- Graph growth figure: `runs\stage2_pilot_real_s2c_analysis\figures\graph_growth.svg`
- Episode viewer: `tools\episode_log_viewer.html`. Drag any run's `steps.jsonl` into the page to inspect prompts and decisions.

## Full Run Readiness

- Ready: DeepSeek API calls, JSON mode, per-step prompt/output logging, resume config checks, budget progress logging, baseline memory files, graph files, filtered analysis.
- Needs before full run: add one retry for `{}` or malformed JSON, decide whether impossible cases count as task failure or correct refusal, and run at least one real graph ablation if budget allows.
